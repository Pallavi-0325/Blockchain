-- Database Schema and Sample Data for Healthcare App

-- Create Database (Optional, if you haven't created it yet)
-- CREATE DATABASE `pallavi-3136370892`;
-- USE `pallavi-3136370892`;

-- Table: Patients
CREATE TABLE IF NOT EXISTS patients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INT,
    gender VARCHAR(10),
    address VARCHAR(255),
    phone VARCHAR(20),
    medical_history TEXT,
    blockchain_account VARCHAR(42)
) ENGINE=InnoDB;

-- Table: Doctors
CREATE TABLE IF NOT EXISTS doctors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    specialization VARCHAR(100),
    phone VARCHAR(20),
    blockchain_account VARCHAR(42)
) ENGINE=InnoDB;

-- Sample Data: Patients
INSERT INTO patients (name, age, gender, address, phone, medical_history, blockchain_account) VALUES 
('John Doe', 35, 'Male', '123 Maple St', '555-0101', 'Hypertension, Allergy to Penicillin', '0xAccount1'),
('Jane Smith', 28, 'Female', '456 Oak Ave', '555-0102', 'Asthma', '0xAccount2'),
('Alice Johnson', 62, 'Female', '789 Pine Rd', '555-0103', 'Diabetes Type 2', '0xAccount3'),
('Bob Brown', 45, 'Male', '321 Elm St', '555-0104', 'None', '0xAccount4'),
('Charlie Davis', 50, 'Male', '654 Cedar Ln', '555-0105', 'High Cholesterol', '0xAccount5');

-- Sample Data: Doctors
INSERT INTO doctors (name, specialization, phone, blockchain_account) VALUES 
('Dr. Emily White', 'Cardiologist', '555-0201', '0xDoctor1'),
('Dr. Michael Green', 'General Practitioner', '555-0202', '0xDoctor2');
